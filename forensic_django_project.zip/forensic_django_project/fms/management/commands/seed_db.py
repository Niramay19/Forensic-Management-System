from django.core.management.base import BaseCommand
from fms.models import (
    Role, UserAccount, EvidenceType, StorageLocation,
    CaseInfo, Suspect, Evidence
)

class Command(BaseCommand):
    help = 'Seeds the database with complete realistic forensic data.'

    def handle(self, *args, **kwargs):

        # ---------------------------------------
        # ROLES
        # ---------------------------------------
        r_admin, _ = Role.objects.get_or_create(role_name='Admin')
        r_inv, _ = Role.objects.get_or_create(role_name='Investigator')
        r_lab, _ = Role.objects.get_or_create(role_name='LabAnalyst')
        r_clerk, _ = Role.objects.get_or_create(role_name='EvidenceClerk')

        # ---------------------------------------
        # USERS
        # ---------------------------------------
        u1, _ = UserAccount.objects.get_or_create(
            username='admin_user',
            defaults={'full_name': 'System Admin', 'role': r_admin}
        )

        u2, _ = UserAccount.objects.get_or_create(
            username='ravi_investigator',
            defaults={'full_name': 'Ravi Kumar', 'role': r_inv}
        )

        u3, _ = UserAccount.objects.get_or_create(
            username='sherin_lab',
            defaults={'full_name': 'Sherin Rose', 'role': r_lab}
        )

        u4, _ = UserAccount.objects.get_or_create(
            username='rahul_clerk',
            defaults={'full_name': 'Rahul Das', 'role': r_clerk}
        )

        u5, _ = UserAccount.objects.get_or_create(
            username='maya_investigator',
            defaults={'full_name': 'Maya Joseph', 'role': r_inv}
        )

        u6, _ = UserAccount.objects.get_or_create(
            username='arjun_lab',
            defaults={'full_name': 'Arjun Verma', 'role': r_lab}
        )

        # ---------------------------------------
        # EVIDENCE TYPES
        # ---------------------------------------
        et_digital, _ = EvidenceType.objects.get_or_create(
            type_name='Digital',
            defaults={'description': 'Electronic evidence such as CCTV footage, mobile data, laptop dumps.'}
        )

        et_physical, _ = EvidenceType.objects.get_or_create(
            type_name='Physical',
            defaults={'description': 'Solid objects used or found at crime scenes such as weapons, tools, clothing.'}
        )

        et_bio, _ = EvidenceType.objects.get_or_create(
            type_name='Biological',
            defaults={'description': 'DNA evidence like blood, hair, saliva, tissue samples.'}
        )

        et_docs, _ = EvidenceType.objects.get_or_create(
            type_name='Documents',
            defaults={'description': 'Printed paper documents, IDs, bank statements, reports.'}
        )

        # ---------------------------------------
        # STORAGE LOCATIONS
        # ---------------------------------------
        sl1, _ = StorageLocation.objects.get_or_create(
            location_name='Locker A1',
            defaults={'location_description': 'Primary secured locker for storing high-priority physical evidence.', 'capacity': 50}
        )

        sl2, _ = StorageLocation.objects.get_or_create(
            location_name='Digital Vault',
            defaults={'location_description': 'Highly secured vault for storing hard disks, pen drives, DVR backups.', 'capacity': 30}
        )

        sl3, _ = StorageLocation.objects.get_or_create(
            location_name='Lab Freezer',
            defaults={'location_description': 'Temperature-controlled freezer for preserving biological samples.', 'capacity': 20}
        )

        sl4, _ = StorageLocation.objects.get_or_create(
            location_name='Weapons Storage Unit',
            defaults={'location_description': 'Storage unit for knives, guns, metal tools and weapons.', 'capacity': 40}
        )

        # ---------------------------------------
        # SUSPECTS
        # ---------------------------------------
        Suspect.objects.get_or_create(
            name='Arjun Menon',
            defaults={'gender': 'male', 'notes': 'Seen in CCTV wearing a black hoodie near the crime scene.'}
        )

        Suspect.objects.get_or_create(
            name='Salman Rahim',
            defaults={'gender': 'male', 'notes': 'Matched witness description; seen fleeing the location.'}
        )

        Suspect.objects.get_or_create(
            name='Priya Varma',
            defaults={'gender': 'female', 'notes': 'Located near crime scene through mobile tower logs.'}
        )

        Suspect.objects.get_or_create(
            name='Nikhil George',
            defaults={'gender': 'male', 'notes': 'Fingerprint partially matched on seized item.'}
        )

        # ---------------------------------------
        # CASES
        # ---------------------------------------
        c1, _ = CaseInfo.objects.get_or_create(
            case_number='CASE-2025-001',
            defaults={
                'title': 'Burglary at Green Street',
                'description': 'Break-in occurred at 2 AM. CCTV shows masked individual entering through back entrance.',
                'priority': 'high',
                'created_by': u2
            }
        )

        c2, _ = CaseInfo.objects.get_or_create(
            case_number='CASE-2025-002',
            defaults={
                'title': 'Cyber Fraud Complaint',
                'description': 'Victim reported phishing attack leading to unauthorized bank withdrawals.',
                'priority': 'medium',
                'created_by': u5
            }
        )

        c3, _ = CaseInfo.objects.get_or_create(
            case_number='CASE-2025-003',
            defaults={
                'title': 'Hit and Run near MG Road',
                'description': 'Motorbike fled after accident. Blood sample found on the road.',
                'priority': 'high',
                'created_by': u2
            }
        )

        c4, _ = CaseInfo.objects.get_or_create(
            case_number='CASE-2025-004',
            defaults={
                'title': 'ATM Skimming Incident',
                'description': 'Skimming device discovered attached to SBI ATM; possible financial data theft.',
                'priority': 'critical',
                'created_by': u5
            }
        )

        c5, _ = CaseInfo.objects.get_or_create(
            case_number='CASE-2025-005',
            defaults={
                'title': 'Domestic Violence Complaint',
                'description': 'Medical evidence and statements recorded from victim during investigation.',
                'priority': 'medium',
                'created_by': u2
            }
        )

        # ---------------------------------------
        # EVIDENCE
        # ---------------------------------------
        evidence_list = [
            ('EV-001', 'Fingerprint sample', 'Fingerprint lifted from window frame.', et_bio, c1, u2, u2, sl1),
            ('EV-002', 'CCTV Footage', 'Footage covering back entrance extracted from DVR.', et_digital, c1, u2, u3, sl2),
            ('EV-010', 'Pen drive recovered', 'Contains suspicious banking logs.', et_digital, c2, u5, u3, sl2),
            ('EV-011', 'Bank account printouts', 'Printed statements showing unauthorized withdrawals.', et_docs, c2, u5, u4, sl1),
            ('EV-020', 'Blood-stained shirt', 'Recovered from MG Road accident site.', et_bio, c3, u2, u3, sl3),
            ('EV-021', 'Broken motorcycle mirror', 'Part of suspected bike found on the road.', et_physical, c3, u2, u4, sl4),
            ('EV-030', 'Skimming device', 'Electronic device attached to ATM card slot.', et_digital, c4, u5, u3, sl2),
            ('EV-031', 'Fake ATM card', 'Counterfeit ATM card used in fraudulent transaction.', et_docs, c4, u5, u4, sl1),
            ('EV-040', 'Medical report', 'Medical report of injuries sustained.', et_docs, c5, u2, u4, sl1),
            ('EV-041', 'Blood sample', 'Blood sample collected for DNA verification.', et_bio, c5, u2, u3, sl3),
        ]

        for code, title, desc, etype, case, collected_by, holder, loc in evidence_list:
            Evidence.objects.get_or_create(
                evidence_code=code,
                defaults={
                    'title': title,
                    'description': desc,
                    'type': etype,
                    'case': case,
                    'collected_by': collected_by,
                    'current_holder': holder,
                    'current_location': loc
                }
            )

        # ---------------------------------------
        # DONE
        # ---------------------------------------
        self.stdout.write(self.style.SUCCESS('FULL DATABASE SEEDED SUCCESSFULLY WITH DESCRIPTIONS!'))