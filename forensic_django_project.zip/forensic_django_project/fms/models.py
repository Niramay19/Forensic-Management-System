from django.db import models
from django.contrib.auth.models import AbstractUser

# -----------------------------
# ROLE MODEL
# -----------------------------
class Role(models.Model):
    role_name = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return self.role_name


# -----------------------------
# CUSTOM USER MODEL
# -----------------------------
class UserAccount(AbstractUser):
    full_name = models.CharField(max_length=150, blank=True)
    phone = models.CharField(max_length=20, blank=True)
    role = models.ForeignKey(Role, on_delete=models.PROTECT, null=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.username


# -----------------------------
# CASE MODEL
# -----------------------------
class CaseInfo(models.Model):
    case_number = models.CharField(max_length=50, unique=True)
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    status = models.CharField(
        max_length=20,
        choices=[
            ('open', 'open'),
            ('in_progress', 'in_progress'),
            ('closed', 'closed'),
            ('archored', 'archived')
        ],
        default='open'
    )
    priority = models.CharField(
        max_length=10,
        choices=[('low', 'low'), ('medium', 'medium'), ('high', 'high'), ('critical', 'critical')],
        default='medium'
    )
    created_by = models.ForeignKey(UserAccount, null=True, on_delete=models.SET_NULL, related_name='cases_created')
    created_at = models.DateTimeField(auto_now_add=True)
    closed_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.case_number} - {self.title}"


# -----------------------------
# SUSPECT MODEL
# -----------------------------
class Suspect(models.Model):
    name = models.CharField(max_length=200)
    dob = models.DateField(null=True, blank=True)
    gender = models.CharField(
        max_length=10,
        choices=[('male', 'male'), ('female', 'female'), ('other', 'other')],
        null=True,
        blank=True
    )
    address = models.TextField(blank=True)
    notes = models.TextField(blank=True)

    def __str__(self):
        return self.name


# -----------------------------
# EVIDENCE TYPE
# -----------------------------
class EvidenceType(models.Model):
    type_name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.type_name


# -----------------------------
# STORAGE LOCATION
# -----------------------------
class StorageLocation(models.Model):
    location_name = models.CharField(max_length=150)
    location_description = models.TextField(blank=True)
    capacity = models.IntegerField(default=0)

    def __str__(self):
        return self.location_name


# -----------------------------
# EVIDENCE
# -----------------------------
class Evidence(models.Model):
    case = models.ForeignKey(CaseInfo, on_delete=models.CASCADE)
    evidence_code = models.CharField(max_length=100, unique=True)
    title = models.CharField(max_length=255, blank=True)
    description = models.TextField(blank=True)
    type = models.ForeignKey(EvidenceType, on_delete=models.SET_NULL, null=True, blank=True)
    condition = models.CharField(max_length=100, blank=True)
    collected_by = models.ForeignKey(UserAccount, null=True, on_delete=models.SET_NULL, related_name='evidence_collected')
    collected_at = models.DateTimeField(null=True, blank=True)
    current_holder = models.ForeignKey(UserAccount, null=True, on_delete=models.SET_NULL, related_name='evidence_holding')
    current_location = models.ForeignKey(StorageLocation, null=True, on_delete=models.SET_NULL)
    status = models.CharField(max_length=20, default='collected')
    chain_integrity_hash = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.evidence_code


# -----------------------------
# EVIDENCE FILES (optional)
# -----------------------------
class EvidenceFile(models.Model):
    evidence = models.ForeignKey(Evidence, on_delete=models.CASCADE)
    file_name = models.CharField(max_length=255)
    file_path = models.CharField(max_length=512)
    uploaded_by = models.ForeignKey(UserAccount, null=True, on_delete=models.SET_NULL)
    uploaded_at = models.DateTimeField(auto_now_add=True)


# -----------------------------
# CHAIN OF CUSTODY LOG
# -----------------------------
class ChainOfCustodyLog(models.Model):
    evidence = models.ForeignKey(Evidence, on_delete=models.CASCADE)
    action = models.CharField(max_length=50)
    from_holder = models.ForeignKey(UserAccount, null=True, blank=True, on_delete=models.SET_NULL, related_name='+')
    to_holder = models.ForeignKey(UserAccount, null=True, blank=True, on_delete=models.SET_NULL, related_name='+')
    from_location = models.ForeignKey(StorageLocation, null=True, blank=True, on_delete=models.SET_NULL, related_name='+')
    to_location = models.ForeignKey(StorageLocation, null=True, blank=True, on_delete=models.SET_NULL, related_name='+')
    performed_by = models.ForeignKey(UserAccount, on_delete=models.PROTECT, related_name='actions_performed')
    performed_at = models.DateTimeField(auto_now_add=True)
    remarks = models.CharField(max_length=500, blank=True)

    def __str__(self):
        return f"Log {self.id} - {self.evidence}"
    