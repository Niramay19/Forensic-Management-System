from django.urls import path
from .views import CaseListCreate, EvidenceListCreate, transfer_evidence

urlpatterns = [
    path('cases/', CaseListCreate.as_view(), name='cases'),
    path('evidence/', EvidenceListCreate.as_view(), name='evidence'),
    path('transfer/', transfer_evidence, name='transfer'),
]