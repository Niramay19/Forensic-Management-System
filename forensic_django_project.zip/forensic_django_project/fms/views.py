from rest_framework import generics
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.db import transaction

from .models import CaseInfo, Evidence, ChainOfCustodyLog
from .serializers import CaseSerializer, EvidenceSerializer, ChainLogSerializer


# -------------------------------------------
# CREATE + LIST CASES
# -------------------------------------------
class CaseListCreate(generics.ListCreateAPIView):
    queryset = CaseInfo.objects.all().order_by('-created_at')
    serializer_class = CaseSerializer


# -------------------------------------------
# CREATE + LIST EVIDENCE
# -------------------------------------------
class EvidenceListCreate(generics.ListCreateAPIView):
    queryset = Evidence.objects.all().order_by('-created_at')
    serializer_class = EvidenceSerializer


# -------------------------------------------
# EVIDENCE TRANSFER (CHAIN OF CUSTODY)
# -------------------------------------------
@api_view(['POST'])
def transfer_evidence(request):
    """
    EXAMPLE PAYLOAD:
    {
        "evidence_id": 1,
        "to_holder": 2,
        "to_location": 1,
        "performed_by": 2,
        "action": "transferred",
        "remarks": "sent to lab"
    }
    """
    data = request.data

    try:
        ev = Evidence.objects.select_for_update().get(pk=data.get('evidence_id'))
    except Evidence.DoesNotExist:
        return Response({'error': 'Evidence not found'}, status=404)

    with transaction.atomic():
        old_holder = ev.current_holder.id if ev.current_holder else None
        old_loc = ev.current_location.id if ev.current_location else None

        # Update evidence fields
        ev.current_holder_id = data.get('to_holder')
        ev.current_location_id = data.get('to_location')
        ev.status = data.get('action', ev.status)
        ev.save()

        # Create chain log
        log = ChainOfCustodyLog.objects.create(
            evidence=ev,
            action=data.get('action', 'transferred'),
            from_holder_id=old_holder,
            to_holder_id=data.get('to_holder'),
            from_location_id=old_loc,
            to_location_id=data.get('to_location'),
            performed_by_id=data.get('performed_by'),
            remarks=data.get('remarks', '')
        )

    return Response({
        'status': 'success',
        'message': 'Evidence transferred successfully!',
        'log_id': log.id
    })