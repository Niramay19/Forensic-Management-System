from rest_framework import serializers
from .models import CaseInfo, Evidence, ChainOfCustodyLog


class CaseSerializer(serializers.ModelSerializer):
    class Meta:
        model = CaseInfo
        fields = '__all__'


class EvidenceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Evidence
        fields = '__all__'


class ChainLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChainOfCustodyLog
        fields = '__all__'
