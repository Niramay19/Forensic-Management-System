from django.contrib import admin
from .models import (
    Role, UserAccount, CaseInfo, Suspect,
    EvidenceType, StorageLocation, Evidence,
    ChainOfCustodyLog, EvidenceFile
)

admin.site.register(Role)
admin.site.register(UserAccount)
admin.site.register(CaseInfo)
admin.site.register(Suspect)
admin.site.register(EvidenceType)
admin.site.register(StorageLocation)
admin.site.register(Evidence)
admin.site.register(ChainOfCustodyLog)
admin.site.register(EvidenceFile)